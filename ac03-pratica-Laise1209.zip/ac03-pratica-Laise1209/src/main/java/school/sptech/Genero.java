package school.sptech;

public enum Genero {
    ACAO,
    AVENTURA,
    COMEDIA,
    DRAMA,
    ROMANCE,
    TERROR;

}
