package school.sptech;

import java.util.ArrayList;
import java.util.List;

public class ServicoStreaming {
    private String nome;
    private List<Midia> midias;
//    private Genero genero;

    public ServicoStreaming(String nome, List<Midia> midia) {
        this.nome = nome;
        this.midias = new ArrayList<>();
    }

    public ServicoStreaming() {}

    public void adicionar(Midia midia){
        midias.add(midia);
    }

    public Integer duracaoTotalPlataforma(){
        Integer tempoTotal = 0;
        for (Midia midia : midias) {
            tempoTotal += midia.calcularDuracaoTotal();
        }
        return tempoTotal;
    }

    public List<Midia> listarPorNotaMaior(Double nota){
        Double maiorNota = 0.0;
        List listaMaiorNota = new ArrayList<>();
        for (Midia midia : midias) {
            if(maiorNota < nota){
                maiorNota = nota;
                listaMaiorNota.add(midia);
            }
        }
        return listaMaiorNota;
    }

    public List<Midia> listarPorGenero(Genero genero){
        List listaMidiaPorGenero = new ArrayList();
        for (Midia midia : midias) {
            if(midia.getGenero().equals(genero)){
                listaMidiaPorGenero.add(midia);
            }
        }
        return listaMidiaPorGenero;
    }

    public List<Midia> listarFilmesPorGenero(Genero genero){
        List listaFilmePorGenero = new ArrayList();
        for (Midia midia : midias) {
            if(midia instanceof Filme){
                if(midia.getGenero().equals(genero)){
                    listaFilmePorGenero.add(midia);
                }
            }
        }
        return listaFilmePorGenero;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
